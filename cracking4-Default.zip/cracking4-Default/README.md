
### WANING IJO IJO
Memex : Tools Ini masih tahap perkembangan jadi Tungu aja update Selanjutnya🙏

Happy Ending muweheeh😅

## PAKE DOANG NGGA FOLLOW, KONTOL LOO
🌟 LOGO
![deskripsi gambar](https://i.ibb.co/wMD8pVH/Screenshot-2022-04-13-12-28-04-850-com-termux.png)
🌟 RESULTS
![deskripsi gambar](https://i.ibb.co/QrsjvJN/Screenshot-2022-04-13-06-54-04-785-com-termux.png)
🐷 Gambar Hanya Pemanis, Selebihnya Cobain Sendiri Ngab🐷
## Instalation
Download apk Termuxnya disini biar ngga eror🌟
[Klik Disini](https://f-droid.org/repo/com.termux_117.apk)👈
```php
$ cd
$ pkg update && apt upgrade 
$ pkg install python git 
$ pip install requests mechanize
$ pip install bs4 future
$ rm -fr cracking4
$ git clone https://github.com/Al-Vino/cracking4
$ ls (L kecil)
$ cd cracking4
$ python crack-4.py
```
# Cara Update
```php
$ cd
$ cd cracking4
$ git pull
$ python crack-4.py
```
## MY SOCIAL MEDIA
[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Al-Vino) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/AdjAlvino)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/legend.alvino)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/mhff_xy) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6283114500777?text=Asalamualaikum+kak+Vino+ganteng)
## KASIH BINTANG WOY🌟🌟🌟🌟🌟🌟🌟
![Typing SVG](https://readme-typing-svg.herokuapp.com?lines=Selamat+Bersenang-senang....!+)
